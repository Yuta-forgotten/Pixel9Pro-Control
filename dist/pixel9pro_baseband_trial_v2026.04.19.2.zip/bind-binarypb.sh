#!/system/bin/sh

MODDIR=${0%/*}
STAGE=${1:-manual}
TARGET="/vendor/firmware/uecapconfig/PLATFORM_9055801516233416490.binarypb"
SOURCE="$MODDIR/system/vendor/firmware/uecapconfig/PLATFORM_9055801516233416490.binarypb"
LOGFILE="/data/local/tmp/pixel_uecap_special_cn_refined_plmn.log"

log_line() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOGFILE"
}

if [ ! -f "$SOURCE" ]; then
  log_line "$STAGE source missing: $SOURCE"
  exit 1
fi

if [ ! -e "$TARGET" ]; then
  log_line "$STAGE target missing: $TARGET"
  exit 1
fi

TARGET_CTX="$(ls -Zd "$TARGET" 2>/dev/null | awk '{print $1}')"
[ -n "$TARGET_CTX" ] && chcon "$TARGET_CTX" "$SOURCE" 2>/dev/null

if mount | grep -F " on $TARGET " >/dev/null 2>&1; then
  umount "$TARGET" 2>/dev/null
fi

if mount --bind "$SOURCE" "$TARGET" >/dev/null 2>&1; then
  log_line "$STAGE bind ok apatch=${APATCH:-false} ctx=${TARGET_CTX:-unknown}"
  exit 0
fi

RC=$?
log_line "$STAGE bind failed rc=$RC apatch=${APATCH:-false}"
exit $RC
