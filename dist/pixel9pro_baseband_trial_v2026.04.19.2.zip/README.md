# Pixel 9 Pro Baseband Trial

独立基带模块，负责：

- `trial_minimal_cn_combo` UECap 候选
- `persist.dbg.volte_avail_ovr=1`
- `persist.dbg.wfc_avail_ovr=1`
- CarrierSettings / APN / China mcfg overlay

不负责：

- 温控
- CPU 调度
- ZRAM / VM 参数
- WebUI

## 适用

- Pixel 9 Pro
- 当前候选 hash：`2870ba9c94145930ad75f1666c6ec2755ac207a7efc0aa4277bdde13cabaae0c`

## 安装建议

请不要与旧的：

- `5G+Pixel56789TenVoLteVo5G-Global.zip`
- `pixel_uecap_special_apatch_magisk_2026.04.03.zip`

同时叠刷。

如果已安装 `pixel9pro_control` 主模块，请先确认它已被独立热控控制台模块替代，避免继续回绑 `special`。
