#!/system/bin/sh

MODDIR=${0%/*}
. "$MODDIR/bind-binarypb.sh" post-fs-data
